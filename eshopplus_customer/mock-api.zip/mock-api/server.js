const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '.env') });

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const storeRoutes = require('./routes/storeRoutes');
const productRoutes = require('./routes/productRoutes');
const userRoutes = require('./routes/userRoutes');
const addressRoutes = require('./routes/addressRoutes');
const cartRoutes = require('./routes/cartRoutes');
const orderRoutes = require('./routes/orderRoutes');
const paymentRoutes = require('./routes/paymentRoutes');
const promoRoutes = require('./routes/promoRoutes');
const ticketRoutes = require('./routes/ticketRoutes');
const chatRoutes = require('./routes/chatRoutes');

const app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.originalUrl}`);
  next();
});

app.get('/', (req, res) => {
  res.json({
    message: 'eShop Plus mock API is running.',
    docs: 'See README.md for usage and mock data instructions.',
  });
});

app.use('/api', storeRoutes);
app.use('/api', productRoutes);
app.use('/api', userRoutes);
app.use('/api', addressRoutes);
app.use('/api', cartRoutes);
app.use('/api', orderRoutes);
app.use('/api', paymentRoutes);
app.use('/api', promoRoutes);
app.use('/api', ticketRoutes);
app.use('/', chatRoutes);

app.use((req, res) => {
  res.status(404).json({ error: true, message: 'Mock endpoint not defined' });
});

const port = process.env.PORT || 3000;

app.listen(port, () => {
  console.log(`Mock API server listening on http://localhost:${port}`);
});

