const fs = require('fs');
const path = require('path');

const mockDirectory = path.join(__dirname, '..', 'mockData');

function toMockFileName(endpoint) {
  return endpoint.replace(/^\/+/, '').replace(/\//g, '_');
}

function normalizeStoreIdValue(requestedStoreId, originalValue) {
  if (requestedStoreId === undefined || requestedStoreId === null) {
    return originalValue;
  }

  const rawValue = Array.isArray(requestedStoreId)
    ? requestedStoreId[0]
    : requestedStoreId;

  if (typeof originalValue === 'number') {
    const parsed = Number(rawValue);
    return Number.isNaN(parsed) ? originalValue : parsed;
  }

  return rawValue.toString();
}

function replaceStoreId(data, requestedStoreId) {
  // Recursively replace store_id in the data structure
  if (Array.isArray(data)) {
    return data.map((item) => replaceStoreId(item, requestedStoreId));
  } else if (data && typeof data === 'object') {
    const newData = {};
    for (const [key, value] of Object.entries(data)) {
      if (key === 'store_id' && (value === '38' || value === 38)) {
        // Replace store_id with the requested one but preserve original type
        newData[key] = normalizeStoreIdValue(requestedStoreId, value);
      } else {
        newData[key] = replaceStoreId(value, requestedStoreId);
      }
    }
    return newData;
  }
  return data;
}

function loadMock(endpoint, queryParams = {}) {
  const fileName = `${toMockFileName(endpoint)}.json`;
  const filePath = path.join(mockDirectory, fileName);

  try {
    const fileContents = fs.readFileSync(filePath, 'utf8');
    let data = JSON.parse(fileContents);
    
    // If a store_id is requested and the data contains store_id, adapt it
    if (queryParams.store_id) {
      console.log(`[MockLoader] ${endpoint} - Replacing store_id with: ${queryParams.store_id}`);
      data = replaceStoreId(data, queryParams.store_id);
    }
    
    return data;
  } catch (error) {
    if (error.code !== 'ENOENT') {
      console.warn(`Failed to parse mock for ${endpoint}: ${error.message}`);
    }
    return { error: true, message: 'Mock data not found' };
  }
}

module.exports = {
  loadMock,
  mockDirectory,
  toMockFileName,
};
