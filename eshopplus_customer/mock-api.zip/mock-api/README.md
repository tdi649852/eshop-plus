# eShop Plus Mock API

Static Express server that mirrors the live eShop Plus backend and serves deterministic JSON responses from the `mockData` directory. Use it during Flutter development to avoid hitting production services.

## ⚠️ Recent Fix (Nov 13, 2025)

**Issue:** Mock API was only loading product sections, not carousel/categories/sliders.  
**Cause:** Several mock data files contained error responses instead of actual data.  
**Fixed:** Replaced error responses in 6 critical files with proper mock data:
- `get_categories.json` (now returns 6 categories)
- `get_slider_images.json` (now returns 3 slider images)
- `get_offer_images.json` (now returns 2 offer images)
- `get_categories_sliders.json` (now returns 2 category sliders)
- `get_offers_sliders.json` (now returns 3 offer sliders)
- `get_brands.json` (now returns 4 brands)

See [BUGFIX_SUMMARY.md](./BUGFIX_SUMMARY.md) for complete details.

## Quick start

```bash
cd mock-api
npm install
cp .env.example .env    # optional – override the default port
npm run dev             # or `npm start`
```

The server listens on `http://localhost:3000` by default. Update `lib/core/configs/appConfig.dart` in your Flutter app so `baseUrl` points to your local address, e.g. `http://localhost:3000`.

## Project layout

- `server.js` – Express bootstrap, shared middleware, and route mounting
- `routes/` – feature-focused routers (stores, products, orders, etc.)
- `mockData/` – JSON payloads returned to the client
- `utils/mockLoader.js` – helper that loads JSON files and falls back to an error response if missing

## Adding or updating mock responses

### Automatic Sync (Recommended)

Run the sync script to automatically fetch responses from the live API:

```bash
npm run sync:mocks
```

This will fetch all public endpoints and save them to `mockData/`. Endpoints requiring authentication or user-specific data are skipped.

### Manual Method

1. Run the real API call once and capture the JSON payload.
2. Save it inside `mockData/` using the endpoint name as the file name, e.g.:
   - `/api/get_stores` → `mockData/get_stores.json`
   - `/chatify/api/chat/auth` → `mockData/chatify_api_chat_auth.json`
3. Restart the mock server if it is running (or wait for nodemon to reload).

### Handling Parameterized Endpoints

Some endpoints require query parameters (e.g., `get_products` needs `store_id`). To mock these:

1. Call the live API with the required parameters:
   ```
   https://eshop-pro.eshopweb.store/api/get_products?store_id=38&limit=10
   ```
2. Save the response to `mockData/get_products.json`
3. The mock will return this response regardless of parameters sent

When a file is missing the server returns:

```json
{ "error": true, "message": "Mock data not found" }
```

## Supported endpoints

Every endpoint defined in `lib/core/api/apiEndPoints.dart` is mocked. Each path is registered to accept both `GET` and `POST` (and `DELETE` where appropriate), so the Flutter app can keep its original HTTP method. See the individual route files for the full lists:

- `routes/storeRoutes.js`
- `routes/productRoutes.js`
- `routes/userRoutes.js`
- `routes/addressRoutes.js`
- `routes/cartRoutes.js`
- `routes/orderRoutes.js`
- `routes/paymentRoutes.js`
- `routes/promoRoutes.js`
- `routes/ticketRoutes.js`
- `routes/chatRoutes.js`

## Sample payloads

Two example files are included to illustrate the structure you should follow:

- `mockData/get_stores.json`
- `mockData/login.json`

Feel free to replace them with real responses from your environment.

## Logging

Each request is logged to the console with its HTTP method and path. Adjust `server.js` if you need more verbose output.

## Need another endpoint?

To mock a new URL:

1. Add the JSON file to `mockData/`.
2. Locate the appropriate router (or create a new one) and append the endpoint to the array passed to `registerMockEndpoints`.
3. Restart the server.

That's it—no additional wiring required.

## Mock Data Coverage

The mock API currently includes **40+ endpoint responses**:

### Public Endpoints (Auto-synced)
- Store & Settings: `get_stores`, `get_settings`, `get_languages`, `get_language_labels`
- Categories & Products: `get_categories`, `get_products`, `get_sections`, `search_products`
- Sellers & Brands: `get_sellers`, `get_brands`, `top_sellers`, `best_sellers`
- Ratings & Reviews: `get_product_rating`, `get_product_faqs`
- Location: `get_cities`, `get_zipcodes`, `get_zipcode_by_city_id`
- Promotions: `get_promo_codes`, `get_offer_images`, `get_slider_images`
- And more...

### User-Specific Endpoints (Sample Data)
- Authentication: `login`, `register_user`, `verify_user`
- Cart: `get_user_cart`
- Orders: `get_orders`
- Address: `get_address`
- Favorites: `get_favorites`
- Notifications: `get_notifications`

To update public endpoint data, run `npm run sync:mocks` anytime.

